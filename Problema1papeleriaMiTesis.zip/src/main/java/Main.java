
/* @autor Sebastian Trujillo Atehortua */

import java.util.Scanner;

public class Main {
  public static void main(String[] args) {

      Papeleria papeleria = new Papeleria(); 
    
      Scanner lectura = new Scanner (System.in);

      int opcion = 0;
      String titulo = "";

      do {
        papeleria.capturarInformacion();
        papeleria.mostrarInformacion(papeleria.getTipo_papel());
        
        titulo = "Menú de opciones:";        
        opcion = papeleria.validarEntero(titulo);
        System.out.println();
      }while(opcion != 2);
  }
}