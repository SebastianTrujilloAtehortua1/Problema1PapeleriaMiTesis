
/* @autor Sebastian Trujillo Atehortua */

import java.util.Scanner;

public class Papeleria {
   private String nombre;
   private int identificacion;
   private int numero_hojas;
   private int numero_imagenes;
   private int  tipo_papel;
   private int  bandera;

   public Papeleria() {
       // default constructor
   }

   public Papeleria(String nombre, int identificacion, int 
    numero_hojas, int numero_imagenes, int tipo_papel, int bandera) {
       this.nombre = nombre;
       this.identificacion = identificacion;
       this.numero_hojas = numero_hojas;
       this.numero_imagenes = numero_imagenes;
       this.tipo_papel = tipo_papel;
       this.bandera = bandera;
   }

   public int getTipo_papel() {
       return tipo_papel;
   }

   public void setTipo_papel(int tipo_papel) {
       this.tipo_papel = tipo_papel;
   }

   public void capturarInformacion(){
      
      String titulo = "";

      System.out.println("Papelería Mi Tesis");

      titulo = "Ingrese el nombre completo del cliente: ";
      nombre = validarNombre(titulo);
      System.out.println();

      titulo = "Ingrese la identificación del cliente: ";
      identificacion = validarEntero(titulo);
      //identificacion = lectura.nextInt();
      System.out.println();

      titulo = "Ingrese el número de hojas a imprimir: ";
      numero_hojas = validarEntero(titulo);
      System.out.println();

      titulo = "Ingrese el número de imágenes a imprimir: ";
      numero_imagenes = validarEntero(titulo);
      System.out.println();

      titulo = "Ingrese el tipo de papel para el empaste:";    
      tipo_papel = validarEntero(titulo);
      System.out.println();
   }
  
   public int calcularCostoTotal(int numero_hojas, int numero_imagenes, int tipo_papel) {

     int precioTotal = 0;

     if(tipo_papel == 1){
       
        precioTotal = (70 * numero_hojas) + (35 * 
        numero_imagenes) + 25000; 
     }
     else{
        precioTotal = (70 * numero_hojas) + (35 * 
        numero_imagenes) + 35000; 
     }

     return precioTotal;
   }

   public void mostrarInformacion(int tipo_papel){

     int precioTotal = 0;
     
     System.out.println("Nombre del cliente: " + nombre);
     System.out.println("Identificación del cliente: " + identificacion);
     System.out.println("Número de hojas a imprimir: " + numero_hojas);
     System.out.println("Número de imagenes a imprimir: " + numero_imagenes);

     if(tipo_papel == 1){
       System.out.println("Empaste de la tesis tapa blanda");
     }
     else{
       System.out.println("Empaste de la tesis tapa dura");
     }

     precioTotal = calcularCostoTotal(numero_hojas, numero_imagenes, tipo_papel);

     System.out.println("Valor total de impresión y empaste de la tesis: " + precioTotal);
     System.out.println();
   }

   public String validarNombre(String titulo){

     Scanner lectura = new Scanner (System.in);
     String cadena = "";

     while(cadena.equals("")){
       System.out.print(titulo);
       cadena = lectura.nextLine();

       if(!cadena.matches("^[A-Za-z ]*$")){
         cadena = "";
       }
     }
     return cadena;
   }

   public int validarEntero(String titulo){

      Scanner lectura = new Scanner (System.in);
      String dato = "";
      int entero = 0;

      while(dato.equals("")){
         
        int dato2 = 0;
        
        if(numero_imagenes != 0 && bandera == 0){
          
           System.out.println(titulo);
           System.out.println("1 para tapa blanda");
           System.out.println("2 para tapa dura");
           System.out.print("->");
           dato = lectura.nextLine();
           bandera = 1;

           dato2 = Integer.parseInt(dato);
           if(dato2 > 2){
             System.out.println("Error al ingresar el tipo de papel para el empaste");
             System.out.println();
             dato = "";
             bandera = 0;
           }
        }
        else if(tipo_papel != 0){

             System.out.println(titulo);
             System.out.println("1 para procesar otro cliente");
             System.out.println("2 para salir");
             System.out.print("->");
             dato = lectura.nextLine();
             bandera = 0;

             dato2 = Integer.parseInt(dato);

             if(dato2 == 1){
               numero_imagenes = 0;
               tipo_papel = 0;
             }
          
             if(dato2 > 2){
               System.out.println("Error al ingresar opción");
               System.out.println();
               dato = "";
               numero_imagenes = 0;
             }
        }
        else if(dato2 < 3){
           System.out.print(titulo);
           dato = lectura.nextLine();
        }
        
        if(!dato.matches("[0-9]*")){
               dato = "";
        }
      }

      entero = Integer.parseInt(dato);
      return entero;
  }
}